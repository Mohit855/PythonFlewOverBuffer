a = 20
print(a)
for i in range(a):
    print(i)
